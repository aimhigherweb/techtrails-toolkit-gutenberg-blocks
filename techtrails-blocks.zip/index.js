import colourContainer from './src/blocks/colour_container'
import avatarSpeech from './src/blocks/avatar_speech'
import subjectAreas from './src/blocks/subject_areas'

colourContainer()
avatarSpeech()
subjectAreas()