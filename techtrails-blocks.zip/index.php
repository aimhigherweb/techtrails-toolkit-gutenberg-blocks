<?php

/**
 * Plugin Name: WiTWA Techtrails Toolkit Custom Gutenberg Blocks
 * Version: 1.0.0
 * Author: AimHigher Web Design
 *
 */


	require_once(__DIR__ . '/src/blocks/colour_container/index.php');
	

?>